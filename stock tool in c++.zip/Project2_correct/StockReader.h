#pragma once 
#include "Candlestick.h"  // Includes the Candlestick class definition for use in this file

using namespace System;
using namespace System::IO;  // Provides input/output functionalities such as reading and writing files.
using namespace System::Collections::Generic;  // Provides access to generic collections like List<T>.


/// StockReader is a class designed to handle reading candlestick stock data from CSV files.
/// This class contains a static method that converts CSV data into a list of Candlestick objects.
public ref class StockReader {
public:

    /// Reads candlestick data from a CSV file located at the specified file path.
    /// This method parses the CSV content and converts each valid line into a Candlestick object.

    static List<Candlestick^>^ ReadFromCSV(String^ filePath);
};
