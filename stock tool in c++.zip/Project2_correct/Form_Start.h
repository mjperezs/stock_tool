#pragma once

namespace Project2_correct {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Resumen de MyForm
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO: agregar c�digo de constructor aqu�
			//
		}

	protected:
		/// <summary>
		/// Limpiar los recursos que se est�n usando.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^ label_StartDate;
	private: System::Windows::Forms::Label^ label_EndDate;
	private: System::Windows::Forms::DateTimePicker^ dateTimePicker_StartDate;
	private: System::Windows::Forms::DateTimePicker^ dateTimePicker_EndDate;
	protected:

	protected:



	private: System::Windows::Forms::Button^ button_LoadTicker;
	private: System::Windows::Forms::OpenFileDialog^ openFileDialog_LoadTicker;


	private:
		/// <summary>
		/// Variable del dise�ador necesaria.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// M�todo necesario para admitir el Dise�ador. No se puede modificar
		/// el contenido de este m�todo con el editor de c�digo.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label_StartDate = (gcnew System::Windows::Forms::Label());
			this->label_EndDate = (gcnew System::Windows::Forms::Label());
			this->dateTimePicker_StartDate = (gcnew System::Windows::Forms::DateTimePicker());
			this->dateTimePicker_EndDate = (gcnew System::Windows::Forms::DateTimePicker());
			this->button_LoadTicker = (gcnew System::Windows::Forms::Button());
			this->openFileDialog_LoadTicker = (gcnew System::Windows::Forms::OpenFileDialog());
			this->SuspendLayout();
			// 
			// label_StartDate
			// 
			this->label_StartDate->AutoSize = true;
			this->label_StartDate->Location = System::Drawing::Point(196, 74);
			this->label_StartDate->Name = L"label_StartDate";
			this->label_StartDate->Size = System::Drawing::Size(58, 13);
			this->label_StartDate->TabIndex = 0;
			this->label_StartDate->Text = L"Start Date:";
			// 
			// label_EndDate
			// 
			this->label_EndDate->AutoSize = true;
			this->label_EndDate->Location = System::Drawing::Point(655, 74);
			this->label_EndDate->Name = L"label_EndDate";
			this->label_EndDate->Size = System::Drawing::Size(55, 13);
			this->label_EndDate->TabIndex = 1;
			this->label_EndDate->Text = L"End Date:";
			// 
			// dateTimePicker_StartDate
			// 
			this->dateTimePicker_StartDate->Location = System::Drawing::Point(99, 128);
			this->dateTimePicker_StartDate->Name = L"dateTimePicker_StartDate";
			this->dateTimePicker_StartDate->Size = System::Drawing::Size(200, 20);
			this->dateTimePicker_StartDate->TabIndex = 2;
			// 
			// dateTimePicker_EndDate
			// 
			this->dateTimePicker_EndDate->Location = System::Drawing::Point(576, 125);
			this->dateTimePicker_EndDate->Name = L"dateTimePicker_EndDate";
			this->dateTimePicker_EndDate->Size = System::Drawing::Size(200, 20);
			this->dateTimePicker_EndDate->TabIndex = 3;
			// 
			// button_LoadTicker
			// 
			this->button_LoadTicker->Location = System::Drawing::Point(390, 125);
			this->button_LoadTicker->Name = L"button_LoadTicker";
			this->button_LoadTicker->Size = System::Drawing::Size(75, 23);
			this->button_LoadTicker->TabIndex = 4;
			this->button_LoadTicker->Text = L"Load Ticker";
			this->button_LoadTicker->UseVisualStyleBackColor = true;
			this->button_LoadTicker->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// openFileDialog_LoadTicker
			// 
			this->openFileDialog_LoadTicker->FileName = L"openFileDialog1";
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(931, 261);
			this->Controls->Add(this->button_LoadTicker);
			this->Controls->Add(this->dateTimePicker_EndDate);
			this->Controls->Add(this->dateTimePicker_StartDate);
			this->Controls->Add(this->label_EndDate);
			this->Controls->Add(this->label_StartDate);
			this->Name = L"MyForm";
			this->Text = L"MyForm";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {
	}
};
}
