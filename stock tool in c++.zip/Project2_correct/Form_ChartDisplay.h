#pragma once
#include "StockReader.h"
#include "Candlestick.h"

namespace CppCLRWinFormsProject {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
    using namespace System::Collections::Generic;
    using namespace System::Windows::Forms::DataVisualization::Charting;





	

	/// <summary>
	/// Summary for Form_ChartDisplay
	/// </summary>
	public ref class Form_ChartDisplay : public System::Windows::Forms::Form
	{
        property List<Candlestick^>^ candlesticks;
        StockReader^ stockReader;

	public:
        Form_ChartDisplay(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

		Form_ChartDisplay(String^ originalFilePath, DateTime startDate, DateTime endDate)
		{
			InitializeComponent();

			stockReader = gcnew StockReader();

			filePath = originalFilePath;
			dateTimePicker_StartRefresh->Value = startDate;
			dateTimePicker_EndRefresh->Value = endDate;

			// Load the full candlesticks once
			candlesticks = loadTicker(originalFilePath);

			// Now show them
			loadAndDisplay();

			this->Show();
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form_ChartDisplay()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^ button_Refresh;
	private: System::Windows::Forms::DateTimePicker^ dateTimePicker_StartRefresh;
	private: System::Windows::Forms::DateTimePicker^ dateTimePicker_EndRefresh;


	protected:


	private: System::Windows::Forms::Label^ label_StartDate;
	private: System::Windows::Forms::Label^ label_EndDate;

	private: System::Windows::Forms::DataVisualization::Charting::Chart^ chart_Candlesticks;

	private: System::Windows::Forms::HScrollBar^ hScrollBar_Margin;

	private: System::Windows::Forms::Label^ label_Margin;
	private: System::Windows::Forms::ComboBox^ comboBox_DownWaves;


	private: System::Windows::Forms::ComboBox^ comboBox2;
	private: System::Windows::Forms::Label^ label_DownWaves;
	private: System::Windows::Forms::Label^ label_UpWaves;




	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

		// Member variables for the chart logic
		String^ filePath;
        StockReader^ stockReader;
		     // All candlesticks (unfiltered)
		List<Candlestick^>^ filteredCandlesticks; // Filtered candlesticks
        List<Candlestick^>^ candlesticks;
		ref class Wave; // Forward declaration for the nested Wave class
		Wave^ selectedWave;
	


#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
            System::Windows::Forms::DataVisualization::Charting::ChartArea^ chartArea1 = (gcnew System::Windows::Forms::DataVisualization::Charting::ChartArea());
            System::Windows::Forms::DataVisualization::Charting::ChartArea^ chartArea2 = (gcnew System::Windows::Forms::DataVisualization::Charting::ChartArea());
            System::Windows::Forms::DataVisualization::Charting::Legend^ legend1 = (gcnew System::Windows::Forms::DataVisualization::Charting::Legend());
            System::Windows::Forms::DataVisualization::Charting::Series^ series1 = (gcnew System::Windows::Forms::DataVisualization::Charting::Series());
            System::Windows::Forms::DataVisualization::Charting::Series^ series2 = (gcnew System::Windows::Forms::DataVisualization::Charting::Series());
            this->button_Refresh = (gcnew System::Windows::Forms::Button());
            this->dateTimePicker_StartRefresh = (gcnew System::Windows::Forms::DateTimePicker());
            this->dateTimePicker_EndRefresh = (gcnew System::Windows::Forms::DateTimePicker());
            this->label_StartDate = (gcnew System::Windows::Forms::Label());
            this->label_EndDate = (gcnew System::Windows::Forms::Label());
            this->chart_Candlesticks = (gcnew System::Windows::Forms::DataVisualization::Charting::Chart());
            this->hScrollBar_Margin = (gcnew System::Windows::Forms::HScrollBar());
            this->label_Margin = (gcnew System::Windows::Forms::Label());
            this->comboBox_DownWaves = (gcnew System::Windows::Forms::ComboBox());
            this->comboBox2 = (gcnew System::Windows::Forms::ComboBox());
            this->label_DownWaves = (gcnew System::Windows::Forms::Label());
            this->label_UpWaves = (gcnew System::Windows::Forms::Label());
            (cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->chart_Candlesticks))->BeginInit();
            this->SuspendLayout();
            // 
            // button_Refresh
            // 
            this->button_Refresh->Location = System::Drawing::Point(415, 443);
            this->button_Refresh->Name = L"button_Refresh";
            this->button_Refresh->Size = System::Drawing::Size(142, 53);
            this->button_Refresh->TabIndex = 12;
            this->button_Refresh->Text = L"Refresh";
            this->button_Refresh->UseVisualStyleBackColor = true;
            this->button_Refresh->Click += gcnew System::EventHandler(this, &Form_ChartDisplay::button_Refresh_Click);
            // 
            // dateTimePicker_StartRefresh
            // 
            this->dateTimePicker_StartRefresh->Location = System::Drawing::Point(140, 458);
            this->dateTimePicker_StartRefresh->Name = L"dateTimePicker_StartRefresh";
            this->dateTimePicker_StartRefresh->Size = System::Drawing::Size(212, 20);
            this->dateTimePicker_StartRefresh->TabIndex = 11;
            this->dateTimePicker_StartRefresh->Value = System::DateTime(2025, 2, 5, 0, 0, 0, 0);
            // 
            // dateTimePicker_EndRefresh
            // 
            this->dateTimePicker_EndRefresh->Location = System::Drawing::Point(711, 457);
            this->dateTimePicker_EndRefresh->Name = L"dateTimePicker_EndRefresh";
            this->dateTimePicker_EndRefresh->Size = System::Drawing::Size(212, 20);
            this->dateTimePicker_EndRefresh->TabIndex = 10;
            // 
            // label_StartDate
            // 
            this->label_StartDate->AutoSize = true;
            this->label_StartDate->Location = System::Drawing::Point(69, 458);
            this->label_StartDate->Name = L"label_StartDate";
            this->label_StartDate->Size = System::Drawing::Size(58, 13);
            this->label_StartDate->TabIndex = 9;
            this->label_StartDate->Text = L"Start Date:";
            // 
            // label_EndDate
            // 
            this->label_EndDate->AutoSize = true;
            this->label_EndDate->Location = System::Drawing::Point(640, 458);
            this->label_EndDate->Name = L"label_EndDate";
            this->label_EndDate->Size = System::Drawing::Size(55, 13);
            this->label_EndDate->TabIndex = 8;
            this->label_EndDate->Text = L"End Date:";
            // 
            // chart_Candlesticks
            // 
            chartArea1->Name = L"ChartArea_OHLC";
            chartArea2->AlignWithChartArea = L"ChartArea_OHLC";
            chartArea2->Name = L"ChartArea_Volume";
            this->chart_Candlesticks->ChartAreas->Add(chartArea1);
            this->chart_Candlesticks->ChartAreas->Add(chartArea2);
            this->chart_Candlesticks->Dock = System::Windows::Forms::DockStyle::Top;
            legend1->Name = L"Legend1";
            this->chart_Candlesticks->Legends->Add(legend1);
            this->chart_Candlesticks->Location = System::Drawing::Point(0, 0);
            this->chart_Candlesticks->Name = L"chart_Candlesticks";
            series1->ChartArea = L"ChartArea_OHLC";
            series1->ChartType = System::Windows::Forms::DataVisualization::Charting::SeriesChartType::Candlestick;
            series1->CustomProperties = L"PriceDownColor=Red, PriceUpColor=0\\, 192\\, 0";
            series1->IsXValueIndexed = true;
            series1->Legend = L"Legend1";
            series1->Name = L"Series_OHLC";
            series1->XValueMember = L"Date";
            series1->XValueType = System::Windows::Forms::DataVisualization::Charting::ChartValueType::Date;
            series1->YValueMembers = L"High,Low,Open,Close";
            series1->YValuesPerPoint = 4;
            series2->ChartArea = L"ChartArea_Volume";
            series2->IsXValueIndexed = true;
            series2->Legend = L"Legend1";
            series2->Name = L"Series_Volume";
            series2->XValueMember = L"Date";
            series2->XValueType = System::Windows::Forms::DataVisualization::Charting::ChartValueType::Date;
            series2->YValueMembers = L"Volume";
            this->chart_Candlesticks->Series->Add(series1);
            this->chart_Candlesticks->Series->Add(series2);
            this->chart_Candlesticks->Size = System::Drawing::Size(1018, 374);
            this->chart_Candlesticks->TabIndex = 13;
            this->chart_Candlesticks->Text = L"chart1";
            this->chart_Candlesticks->Click += gcnew System::EventHandler(this, &Form_ChartDisplay::chart_Candlesticks_Click);
            // 
            // hScrollBar_Margin
            // 
            this->hScrollBar_Margin->LargeChange = 1;
            this->hScrollBar_Margin->Location = System::Drawing::Point(72, 404);
            this->hScrollBar_Margin->Maximum = 4;
            this->hScrollBar_Margin->Minimum = 1;
            this->hScrollBar_Margin->Name = L"hScrollBar_Margin";
            this->hScrollBar_Margin->Size = System::Drawing::Size(805, 24);
            this->hScrollBar_Margin->TabIndex = 14;
            this->hScrollBar_Margin->Value = 1;
            this->hScrollBar_Margin->Scroll += gcnew System::Windows::Forms::ScrollEventHandler(this, &Form_ChartDisplay::hScrollBar_Margin_Scroll);
            // 
            // label_Margin
            // 
            this->label_Margin->AutoSize = true;
            this->label_Margin->Location = System::Drawing::Point(459, 377);
            this->label_Margin->Name = L"label_Margin";
            this->label_Margin->Size = System::Drawing::Size(39, 13);
            this->label_Margin->TabIndex = 15;
            this->label_Margin->Text = L"Margin";
            // 
            // comboBox_DownWaves
            // 
            this->comboBox_DownWaves->FormattingEnabled = true;
            this->comboBox_DownWaves->Location = System::Drawing::Point(267, 540);
            this->comboBox_DownWaves->Name = L"comboBox_DownWaves";
            this->comboBox_DownWaves->Size = System::Drawing::Size(182, 21);
            this->comboBox_DownWaves->TabIndex = 16;
            this->comboBox_DownWaves->SelectedIndexChanged += gcnew System::EventHandler(this, &Form_ChartDisplay::comboBox_DownWaves_SelectedIndexChanged);
            // 
            // comboBox2
            // 
            this->comboBox2->FormattingEnabled = true;
            this->comboBox2->Location = System::Drawing::Point(524, 540);
            this->comboBox2->Name = L"comboBox2";
            this->comboBox2->Size = System::Drawing::Size(208, 21);
            this->comboBox2->TabIndex = 17;
            this->comboBox2->SelectedIndexChanged += gcnew System::EventHandler(this, &Form_ChartDisplay::comboBox2_SelectedIndexChanged);
            // 
            // label_DownWaves
            // 
            this->label_DownWaves->AutoSize = true;
            this->label_DownWaves->Location = System::Drawing::Point(323, 524);
            this->label_DownWaves->Name = L"label_DownWaves";
            this->label_DownWaves->Size = System::Drawing::Size(72, 13);
            this->label_DownWaves->TabIndex = 18;
            this->label_DownWaves->Text = L"Down Waves";
            // 
            // label_UpWaves
            // 
            this->label_UpWaves->AutoSize = true;
            this->label_UpWaves->Location = System::Drawing::Point(595, 524);
            this->label_UpWaves->Name = L"label_UpWaves";
            this->label_UpWaves->Size = System::Drawing::Size(58, 13);
            this->label_UpWaves->TabIndex = 19;
            this->label_UpWaves->Text = L"Up Waves";
            // 
            // Form_ChartDisplay
            // 
            this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
            this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
            this->ClientSize = System::Drawing::Size(1018, 589);
            this->Controls->Add(this->label_UpWaves);
            this->Controls->Add(this->label_DownWaves);
            this->Controls->Add(this->comboBox2);
            this->Controls->Add(this->comboBox_DownWaves);
            this->Controls->Add(this->label_Margin);
            this->Controls->Add(this->hScrollBar_Margin);
            this->Controls->Add(this->chart_Candlesticks);
            this->Controls->Add(this->button_Refresh);
            this->Controls->Add(this->dateTimePicker_StartRefresh);
            this->Controls->Add(this->dateTimePicker_EndRefresh);
            this->Controls->Add(this->label_StartDate);
            this->Controls->Add(this->label_EndDate);
            this->Name = L"Form_ChartDisplay";
            this->Text = L"Form_ChartDisplay";
            this->Load += gcnew System::EventHandler(this, &Form_ChartDisplay::Form_ChartDisplay_Load);
            (cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->chart_Candlesticks))->EndInit();
            this->ResumeLayout(false);
            this->PerformLayout();

        }
#pragma endregion
	private: System::Void Form_ChartDisplay_Load(System::Object^ sender, System::EventArgs^ e) {
        comboBox2->SelectedIndexChanged += gcnew System::EventHandler(this, &Form_ChartDisplay::comboBox2_SelectedIndexChanged);
        comboBox_DownWaves->SelectedIndexChanged += gcnew System::EventHandler(this, &Form_ChartDisplay::comboBox_DownWaves_SelectedIndexChanged);
        hScrollBar_Margin->Scroll += gcnew ScrollEventHandler(this, &Form_ChartDisplay::hScrollBar_Margin_Scroll);
	}

	ref class Wave
	{
	public:
		int StartIndex;
		int EndIndex;
		DateTime StartDate;
		DateTime EndDate;
		bool IsUpWave;
		virtual String^ ToString() override
		{
			return String::Format("{0} - {1}", StartDate.ToShortDateString(), EndDate.ToShortDateString());
		}
	};

    // Loads candlestick data from a CSV file and reverses the list if needed.
    List<Candlestick^>^ loadTicker(String^ filename)
    {
        List<Candlestick^>^ listOfCandlesticks = StockReader::ReadFromCSV(filename);
        if (listOfCandlesticks->Count >= 2)
        {
            if (listOfCandlesticks[0]->Date > listOfCandlesticks[1]->Date)
            {
                listOfCandlesticks->Reverse();
            }
        }
        return listOfCandlesticks;
    }

    // Sets the form title and displays the stock data.
    void loadAndDisplay()
    {
        this->Text = filePath;
        displayStock();
    }

    // Filters candlesticks based on the provided start and end dates.
    List<Candlestick^>^ FilterCandlesticksByDate(List<Candlestick^>^ listOfCandlesticks, DateTime startDate, DateTime endDate)
    {
        List<Candlestick^>^ filtered = gcnew List<Candlestick^>();
        for each (Candlestick ^ c in listOfCandlesticks)
        {
            if (c->Date >= startDate && c->Date <= endDate)
                filtered->Add(c);
        }
        return filtered;
    }

    // Finds the indices for peaks and valleys within a given margin.
    void FindPeaksAndValleys(List<Candlestick^>^ candlesticks, int margin,
        [System::Runtime::InteropServices::Out] List<int>^% peakIndices,
        [System::Runtime::InteropServices::Out] List<int>^% valleyIndices)
    {
        peakIndices = gcnew List<int>();
        valleyIndices = gcnew List<int>();

        if (candlesticks == nullptr || candlesticks->Count == 0)
            return;
        if (margin < 1)
            margin = 1;

        for (int i = 0; i < candlesticks->Count; i++)
        {
            int start = Math::Max(i - margin, 0);
            int end = Math::Min(i + margin, candlesticks->Count - 1);

            double currentHigh = candlesticks[i]->High;
            double currentLow = candlesticks[i]->Low;

            bool isPeak = true;
            bool isValley = true;

            for (int j = start; j <= end; j++)
            {
                if (candlesticks[j]->High > currentHigh)
                    isPeak = false;
                if (candlesticks[j]->Low < currentLow)
                    isValley = false;
            }

            if (isPeak)
                peakIndices->Add(i);
            if (isValley)
                valleyIndices->Add(i);
        }
    }

    // Adds annotations to the chart marking peaks and valleys.
    void AnnotatePeaksAndValleys()
    {
        chart_Candlesticks->Annotations->Clear();

        int margin = hScrollBar_Margin->Value;
        List<Candlestick^>^ data = filteredCandlesticks;
        if (data == nullptr || data->Count == 0)
            return;

        List<int>^ peakIndices;
        List<int>^ valleyIndices;
        FindPeaksAndValleys(data, margin, peakIndices, valleyIndices);

        Series^ seriesOHLC = chart_Candlesticks->Series["Series_OHLC"];
        if (seriesOHLC->Points->Count == 0)
            return;

        // Mark peaks in green
        for each (int idx in peakIndices)
        {
            if (idx < seriesOHLC->Points->Count)
            {
                TextAnnotation^ peakAnno = gcnew TextAnnotation();
                peakAnno->Text = "P";
                peakAnno->ForeColor = Color::Green;
                peakAnno->Font = gcnew System::Drawing::Font("Arial", 8, System::Drawing::FontStyle::Bold);

                peakAnno->AnchorDataPoint = seriesOHLC->Points[idx];
                peakAnno->AnchorAlignment = ContentAlignment::BottomCenter;
                chart_Candlesticks->Annotations->Add(peakAnno);
            }
        }

        // Mark valleys in red
        for each (int idx in valleyIndices)
        {
            if (idx < seriesOHLC->Points->Count)
            {
                TextAnnotation^ valleyAnno = gcnew TextAnnotation();
                valleyAnno->Text = "V";
                valleyAnno->ForeColor = Color::Red;
                
                valleyAnno->Font = gcnew System::Drawing::Font("Arial", 8, System::Drawing::FontStyle::Bold);

                valleyAnno->AnchorDataPoint = seriesOHLC->Points[idx];
                valleyAnno->AnchorAlignment = ContentAlignment::TopCenter;
                chart_Candlesticks->Annotations->Add(valleyAnno);
            }
        }
    }

    // Merges and sorts the peak/valley indices and creates Wave objects.
    void BuildWaves(List<int>^ peakIndices, List<int>^ valleyIndices, List<Candlestick^>^ data,
        [System::Runtime::InteropServices::Out] List<Wave^>^% upWaves,
        [System::Runtime::InteropServices::Out] List<Wave^>^% downWaves)
    {
        upWaves = gcnew List<Wave^>();
        downWaves = gcnew List<Wave^>();

        List<int>^ combined = gcnew List<int>();
        for each (int i in peakIndices)
            combined->Add(i);
        for each (int i in valleyIndices)
            combined->Add(i);
        combined->Sort();

        for (int i = 0; i < combined->Count - 1; i++)
        {
            int curr = combined[i];
            int next = combined[i + 1];

            // Up wave: valley -> peak
            bool currIsValley = valleyIndices->Contains(curr);
            bool nextIsPeak = peakIndices->Contains(next);
            if (currIsValley && nextIsPeak)
            {
                Wave^ wave = gcnew Wave();
                wave->StartIndex = curr;
                wave->EndIndex = next;
                wave->StartDate = data[curr]->Date;
                wave->EndDate = data[next]->Date;
                wave->IsUpWave = true;
                upWaves->Add(wave);
            }

            // Down wave: peak -> valley
            bool currIsPeak = peakIndices->Contains(curr);
            bool nextIsValley = valleyIndices->Contains(next);
            if (currIsPeak && nextIsValley)
            {
                Wave^ wave = gcnew Wave();
                wave->StartIndex = curr;
                wave->EndIndex = next;
                wave->StartDate = data[curr]->Date;
                wave->EndDate = data[next]->Date;
                wave->IsUpWave = false;
                downWaves->Add(wave);
            }
        }
    }

    // Displays the stock by filtering, normalizing, binding the chart, annotating, and populating the combo boxes.
    void displayStock()
    {
        filteredCandlesticks = FilterCandlesticksByDate(candlesticks, dateTimePicker_StartRefresh->Value, dateTimePicker_EndRefresh->Value);

        if (filteredCandlesticks == nullptr || filteredCandlesticks->Count == 0)
        {
            chart_Candlesticks->DataSource = nullptr;
            chart_Candlesticks->DataBind();
            return;
        }

        normalizeChart(filteredCandlesticks);

        chart_Candlesticks->DataSource = filteredCandlesticks;
        chart_Candlesticks->DataBind();

        AnnotatePeaksAndValleys();
        PopulateWaveComboBoxes();

        chart_Candlesticks->Show();
    }

    // Normalizes the chart�s Y-axis based on the min and max values.
    void normalizeChart(List<Candlestick^>^ listOfCandlesticks)
    {
        if (listOfCandlesticks == nullptr || listOfCandlesticks->Count == 0)
            return;

        double minValue = Double::MaxValue;
        double maxValue = Double::MinValue;

        for each (Candlestick ^ c in listOfCandlesticks)
        {
            if (c->Low < minValue)
                minValue = c->Low;
            if (c->High > maxValue)
                maxValue = c->High;
        }

        double padding = (maxValue - minValue) * 0.02;
        
        // Set the Y-axis minimum value to the new padded minimum
        chart_Candlesticks->ChartAreas["ChartArea_OHLC"]->AxisY->Minimum = minValue;

        // Set the Y-axis maximum value to the new padded maximum
        chart_Candlesticks->ChartAreas["ChartArea_OHLC"]->AxisY->Maximum = maxValue;
    }

    // Populates the combo boxes with Up and Down Wave objects.
    void PopulateWaveComboBoxes()
    {
        int margin = hScrollBar_Margin->Value;
        if (filteredCandlesticks == nullptr || filteredCandlesticks->Count == 0)
        {
            comboBox2->DataSource = nullptr;
            comboBox_DownWaves->DataSource = nullptr;
            return;
        }

        List<int>^ peakIdx;
        List<int>^ valleyIdx;
        FindPeaksAndValleys(filteredCandlesticks, margin, peakIdx, valleyIdx);

        List<Wave^>^ upWaves;
        List<Wave^>^ downWaves;
        BuildWaves(peakIdx, valleyIdx, filteredCandlesticks, upWaves, downWaves);

        comboBox2->DataSource = upWaves;
        comboBox_DownWaves->DataSource = downWaves;
    }

    // Clears any wave-related annotations from the chart.
    void ClearWaveAnnotations()
    {
        for (int i = chart_Candlesticks->Annotations->Count - 1; i >= 0; i--)
        {
            Annotation^ anno = chart_Candlesticks->Annotations[i];
            if (anno->Name == "waveRectangle" || anno->Name == "waveLine")
            {
                chart_Candlesticks->Annotations->RemoveAt(i);
            }
        }
    }

    // Draws a given wave (with a rectangle and a line) on the chart.
    void DrawWave(Wave^ wave, List<Candlestick^>^ data, bool isUpWave)
    {
        ClearWaveAnnotations();

        if (wave == nullptr || data == nullptr || data->Count == 0)
            return;

        double minPrice = Double::MaxValue;
        double maxPrice = Double::MinValue;
        for (int i = wave->StartIndex; i <= wave->EndIndex; i++)
        {
            if (data[i]->Low < minPrice)
                minPrice = data[i]->Low;
            if (data[i]->High > maxPrice)
                maxPrice = data[i]->High;
        }

        double xStart = data[wave->StartIndex]->Date.ToOADate();
        double xEnd = data[wave->EndIndex]->Date.ToOADate();

        RectangleAnnotation^ rect = gcnew RectangleAnnotation();
        rect->Name = "waveRectangle";
        rect->AxisX = chart_Candlesticks->ChartAreas["ChartArea_OHLC"]->AxisX;
        rect->AxisY = chart_Candlesticks->ChartAreas["ChartArea_OHLC"]->AxisY;
        rect->LineColor = isUpWave ? Color::Green : Color::Red;
        rect->BackColor = Color::Transparent;
        rect->ClipToChartArea = "ChartArea_OHLC";
        rect->X = xStart;
        rect->Y = (double)maxPrice;
        rect->Width = xEnd - xStart;
        rect->Height = (double)(maxPrice - minPrice);
        chart_Candlesticks->Annotations->Add(rect);

        LineAnnotation^ diag = gcnew LineAnnotation();
        diag->Name = "waveLine";
        diag->AxisX = chart_Candlesticks->ChartAreas["ChartArea_OHLC"]->AxisX;
        diag->AxisY = chart_Candlesticks->ChartAreas["ChartArea_OHLC"]->AxisY;
        diag->LineColor = isUpWave ? Color::Green : Color::Red;
        diag->LineWidth = 2;
        diag->ClipToChartArea = "ChartArea_OHLC";

        if (isUpWave)
        {
            diag->X = xStart;
            diag->Y = (double)data[wave->StartIndex]->Low;
            diag->AnchorX = xEnd;
            diag->AnchorY = (double)data[wave->EndIndex]->High;
        }
        else
        {
            diag->X = xStart;
            diag->Y = (double)data[wave->StartIndex]->High;
            diag->AnchorX = xEnd;
            diag->AnchorY = (double)data[wave->EndIndex]->Low;
        }
        chart_Candlesticks->Annotations->Add(diag);
    }

    // Draws the selected wave (using data from the filtered candlesticks).
    void DrawSelectedWave()
    {
        if (selectedWave == nullptr || filteredCandlesticks == nullptr || filteredCandlesticks->Count == 0)
            return;

        ClearWaveAnnotations();

        Candlestick^ startCandle = filteredCandlesticks[selectedWave->StartIndex];
        Candlestick^ endCandle = filteredCandlesticks[selectedWave->EndIndex];

        double startX = selectedWave->StartIndex + 1;
        double endX = selectedWave->EndIndex + 1;
        double startY, endY;

        if (!selectedWave->IsUpWave) // down wave
        {
            startY = (double)startCandle->High;
            endY = (double)endCandle->Low;
        }
        else // up wave
        {
            startY = (double)startCandle->Low;
            endY = (double)endCandle->High;
        }

        Color waveColor = selectedWave->IsUpWave ? Color::Green : Color::Red;
        ChartArea^ chartArea = chart_Candlesticks->ChartAreas["ChartArea_OHLC"];

        RectangleAnnotation^ rect = gcnew RectangleAnnotation();
        rect->Name = "waveRectangle";
        rect->AxisX = chartArea->AxisX;
        rect->AxisY = chartArea->AxisY;
        rect->X = startX;
        rect->Y = Math::Max(startY, endY);
        rect->Width = endX - startX;
        rect->Height = Math::Abs(endY - startY) * -1;
        rect->BackColor = Color::FromArgb(30, waveColor);
        rect->LineColor = waveColor;
        rect->LineWidth = 3;
        rect->IsSizeAlwaysRelative = false;
        rect->ClipToChartArea = chartArea->Name;
        chart_Candlesticks->Annotations->Add(rect);

        LineAnnotation^ line = gcnew LineAnnotation();
        line->Name = "waveLine";
        line->AxisX = chartArea->AxisX;
        line->AxisY = chartArea->AxisY;
        line->X = startX;
        line->Y = startY;
        line->Width = endX - startX;
        line->Height = endY - startY;
        line->LineColor = waveColor;
        line->LineWidth = 2;
        line->IsSizeAlwaysRelative = false;
        line->ClipToChartArea = chartArea->Name;
        chart_Candlesticks->Annotations->Add(line);

        chart_Candlesticks->Invalidate();
    }







private: System::Void button_Refresh_Click(System::Object^ sender, System::EventArgs^ e) {
    displayStock();

}
private: System::Void hScrollBar_Margin_Scroll(System::Object^ sender, System::Windows::Forms::ScrollEventArgs^ e) {
    displayStock();
}
private: System::Void comboBox_DownWaves_SelectedIndexChanged(System::Object^ sender, System::EventArgs^ e) {
    Wave^ wave = dynamic_cast<Wave^>(comboBox_DownWaves->SelectedItem);
    if (wave == nullptr) return;
    selectedWave = wave;
    DrawSelectedWave();
}
private: System::Void comboBox2_SelectedIndexChanged(System::Object^ sender, System::EventArgs^ e) {
    Wave^ wave = dynamic_cast<Wave^>(comboBox2->SelectedItem);
    if (wave == nullptr) return;
    selectedWave = wave;
    DrawSelectedWave();
}
private: System::Void chart_Candlesticks_Click(System::Object^ sender, System::EventArgs^ e) {
}
};
}
