#pragma once 

using namespace System;
#include "string"  // String library 

/// Represents a candlestick object that holds stock trading data for a specific time period.
/// Each instance stores Open, High, Low, Close prices, the trading Volume, and the corresponding Date.

public ref class Candlestick
{
public:
    // Properties to store candlestick data for a given time period
    property unsigned long Volume;  // Total trading volume
    property double Close;  // Closing price of the stock 
    property double Low;  // Lowest trading price of the stock 
    property double High;  // Highest trading price of the stock 
    property double Open;  // Opening price of the stock
    property DateTime Date;  // Date and time for the candlestick data


    /// Default constructor for Candlestick. Initializes an empty instance with default values.
    Candlestick() {}


    /// Parameterized constructor that initializes all candlestick properties.
    Candlestick(DateTime date, double open, double high, double low, double close, unsigned long volume)
    {
        // Initialize the object's properties with the given parameters.
        this->Date = date;  // Set the date of the candlestick
        this->Open = open;  // Set the opening price
        this->High = high;  // Set the highest price
        this->Low = low;  // Set the lowest price
        this->Close = close;  // Set the closing price
        this->Volume = volume;  // Set the trading volume
    }


    /// Constructor that initializes a Candlestick object from a CSV-formatted string.
    /// The string should follow the format: "Date, Open, High, Low, Close, Volume".

    Candlestick(String^ candlestickString);
};
