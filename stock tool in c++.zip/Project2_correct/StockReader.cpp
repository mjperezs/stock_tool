#include "pch.h"
#include "StockReader.h"
//#include "Candlestick.h"

/// Reads candlestick data from a CSV file and returns a list of Candlestick objects.
/// Each line in the CSV file should contain the necessary data to create a Candlestick instance.
///"filePath" The path to the CSV file containing candlestick data
/// returns a list of Candlestick objects created from the CSV data.</returns>
List<Candlestick^>^ StockReader::ReadFromCSV(String^ filePath)
{
    // Create a new list to store the candlesticks
    List<Candlestick^>^ candlesticks = gcnew List<Candlestick^>();

    try
    {
        // Attempt to open the file using StreamReader
        StreamReader^ reader = gcnew StreamReader(filePath);

        // Read and discard the first line (assuming it contains headers like Date, Open, High, Low, Close)
        String^ line = reader->ReadLine();

        // Loop through the file until reaching the end
        while (!reader->EndOfStream)
        {
            // Read the next line from the CSV
            line = reader->ReadLine();

            // Check if the line is not empty or composed of whitespace characters
            if (!String::IsNullOrWhiteSpace(line))
            {
                // Create a new Candlestick object using the CSV line
                Candlestick^ theNewcandlestick = gcnew Candlestick(line);

                // Add the newly created candlestick to the list
                candlesticks->Add(theNewcandlestick);
            }
        }

        // Close the StreamReader after reading the file
        reader->Close();
    }
    catch (Exception^ ex)
    {

        // This writes the error message to the console for debugging purposes
        Console::WriteLine("Error reading file: " + ex->Message);
    }

    // Return the list of candlesticks created from the CSV file
    return candlesticks;
}
