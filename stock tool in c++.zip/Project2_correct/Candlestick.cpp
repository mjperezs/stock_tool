#include "pch.h" 
#include "Candlestick.h"  // Includes the definition of the Candlestick class.

/// Constructor that initializes a Candlestick object by parsing a CSV-formatted string.
/// Each token from the CSV line is assigned to its corresponding property (Date, Open, High, Low, Close, Volume)
/// candlestickString is a CSV-formatted string containing candlestick data
/// ArgumentException thrown when the input string does not have the expected format
Candlestick::Candlestick(String^ candlestickString)
{
    // Define separators used to split the CSV line.
    array<wchar_t>^ separators = gcnew array<wchar_t>{ ',', '\"' };

    // Split the input string into tokens using the defined separators.
    // StringSplitOptions::RemoveEmptyEntries ensures no empty elements are included in the result.
    array<String^>^ tokens = candlestickString->Split(separators, StringSplitOptions::RemoveEmptyEntries);

    // Ensure the string contains exactly 6 values
    if (tokens->Length == 6)
    {
        // Parsing each value and assigning it to the corresponding property
        this->Date = DateTime::Parse(tokens[0]);  // Convert the first token into a DateTime object
        this->Open = Convert::ToDouble(tokens[1]);  // Parse the 'Open' price as a double
        this->High = Convert::ToDouble(tokens[2]);  // Parse the 'High' price as a double
        this->Low = Convert::ToDouble(tokens[3]);  // Parse the 'Low' price as a double
        this->Close = Convert::ToDouble(tokens[4]);  // Parse the 'Close' price as a double
        this->Volume = Convert::ToInt64(tokens[5]);  // Parse the 'Volume' as a 64-bit integer
    }
    else
    {
        // Throw an exception if the input string does not have the correct format
        throw gcnew ArgumentException("The input string is not in the correct format.");
    }
}
