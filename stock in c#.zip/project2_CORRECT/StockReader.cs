﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;

namespace StockAnalysis
{
    /// Responsible for reading stock data from CSV files and converting it into candlestick objects.
    public class StockReader
    {
        /// Reads candlestick data from a CSV file.
        public static List<Candlestick> ReadCandlesticksFromCsv(string filePath)
        {
            // Initialize a list to store candlestick data from the CSV
            var candlesticks = new List<Candlestick>();

            // Open the CSV file for reading using a StreamReader object
            using (var reader = new StreamReader(filePath))
            {
                // Read and skip the header line since it contains column names, not data
                var header = reader.ReadLine();

                // Continue reading lines until reaching the end of the file
                while (!reader.EndOfStream)
                {
                    // Read the next line from the CSV file
                    var line = reader.ReadLine();

#if false
                    // This block of code is disabled and serves as an alternative approach to parse CSV manually

                    // Define delimiters for parsing CSV 
                    char[] delimiters = { ',', '\"' };
                    // Split the line into values using the defined delimiters
                    var values = line.Split(delimiters, StringSplitOptions.RemoveEmptyEntries);

                    // Check if the line contains exactly 6 values (Date, Open, High, Low, Close, Volume)
                    if (values.Length == 6)
                    {
                        // Create a new candlestick object by parsing the individual values
                        var candlestick = new Candlestick
                        {
                            Date = DateTime.ParseExact(values[0], "yyyy-MM-dd", CultureInfo.InvariantCulture), // Parse date
                            Open = decimal.Parse(values[1], CultureInfo.InvariantCulture), // Parse opening price
                            High = decimal.Parse(values[2], CultureInfo.InvariantCulture), // Parse highest price
                            Low = decimal.Parse(values[3], CultureInfo.InvariantCulture), // Parse lowest price
                            Close = decimal.Parse(values[4], CultureInfo.InvariantCulture), // Parse closing price
                            Volume = ulong.Parse(values[5], CultureInfo.InvariantCulture) // Parse trading volume
                        };

                        // Add the newly created candlestick to the list
                        candlesticks.Add(candlestick);
                    }
#endif

                    // Create a new candlestick using the constructor that automatically parses the CSV-formatted string
                    var candlestick = new Candlestick(line);

                    // Add the parsed candlestick to the list
                    candlesticks.Add(candlestick);
                }
            }

            // Return the complete list of candlestick data
            return candlesticks;
        }
    }
}
