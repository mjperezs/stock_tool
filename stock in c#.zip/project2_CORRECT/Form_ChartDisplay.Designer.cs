﻿namespace project2_MJP
{
    partial class Form_ChartDisplay
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.chart_Candlesticks = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.button_Refresh = new System.Windows.Forms.Button();
            this.dateTimePicker_StartRefresh = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker_EndRefresh = new System.Windows.Forms.DateTimePicker();
            this.ScrollBar_Margin = new System.Windows.Forms.HScrollBar();
            this.comboBox_UpWaves = new System.Windows.Forms.ComboBox();
            this.comboBox_DownWaves = new System.Windows.Forms.ComboBox();
            this.label_DownWaves = new System.Windows.Forms.Label();
            this.label_UpWaves = new System.Windows.Forms.Label();
            this.label_Margin = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.chart_Candlesticks)).BeginInit();
            this.SuspendLayout();
            // 
            // chart_Candlesticks
            // 
            chartArea1.Name = "ChartArea_OHLC";
            chartArea2.AlignWithChartArea = "ChartArea_OHLC";
            chartArea2.Name = "ChartArea_Volume";
            this.chart_Candlesticks.ChartAreas.Add(chartArea1);
            this.chart_Candlesticks.ChartAreas.Add(chartArea2);
            this.chart_Candlesticks.Dock = System.Windows.Forms.DockStyle.Top;
            legend1.Name = "Legend1";
            this.chart_Candlesticks.Legends.Add(legend1);
            this.chart_Candlesticks.Location = new System.Drawing.Point(0, 0);
            this.chart_Candlesticks.Name = "chart_Candlesticks";
            series1.ChartArea = "ChartArea_OHLC";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Candlestick;
            series1.CustomProperties = "PriceDownColor=Red, PriceUpColor=0\\, 192\\, 0";
            series1.IsXValueIndexed = true;
            series1.Legend = "Legend1";
            series1.Name = "Series_OHLC";
            series1.XValueMember = "Date";
            series1.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Date;
            series1.YValueMembers = "High,Low,Open,Close";
            series1.YValuesPerPoint = 4;
            series2.ChartArea = "ChartArea_Volume";
            series2.IsXValueIndexed = true;
            series2.Legend = "Legend1";
            series2.Name = "Series_Volume";
            series2.XValueMember = "Date";
            series2.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Date;
            series2.YValueMembers = "Volume";
            this.chart_Candlesticks.Series.Add(series1);
            this.chart_Candlesticks.Series.Add(series2);
            this.chart_Candlesticks.Size = new System.Drawing.Size(1124, 307);
            this.chart_Candlesticks.TabIndex = 0;
            this.chart_Candlesticks.Text = "chart1";
            this.chart_Candlesticks.Click += new System.EventHandler(this.chart_Candlesticks_Click_1);
            // 
            // button_Refresh
            // 
            this.button_Refresh.Location = new System.Drawing.Point(458, 400);
            this.button_Refresh.Name = "button_Refresh";
            this.button_Refresh.Size = new System.Drawing.Size(75, 23);
            this.button_Refresh.TabIndex = 1;
            this.button_Refresh.Text = "Refresh";
            this.button_Refresh.UseVisualStyleBackColor = true;
            this.button_Refresh.Click += new System.EventHandler(this.button_Refresh_Click);
            // 
            // dateTimePicker_StartRefresh
            // 
            this.dateTimePicker_StartRefresh.Location = new System.Drawing.Point(176, 403);
            this.dateTimePicker_StartRefresh.Name = "dateTimePicker_StartRefresh";
            this.dateTimePicker_StartRefresh.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker_StartRefresh.TabIndex = 2;
            // 
            // dateTimePicker_EndRefresh
            // 
            this.dateTimePicker_EndRefresh.Location = new System.Drawing.Point(645, 403);
            this.dateTimePicker_EndRefresh.Name = "dateTimePicker_EndRefresh";
            this.dateTimePicker_EndRefresh.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker_EndRefresh.TabIndex = 3;
            // 
            // ScrollBar_Margin
            // 
            this.ScrollBar_Margin.LargeChange = 1;
            this.ScrollBar_Margin.Location = new System.Drawing.Point(86, 342);
            this.ScrollBar_Margin.Maximum = 4;
            this.ScrollBar_Margin.Minimum = 1;
            this.ScrollBar_Margin.Name = "ScrollBar_Margin";
            this.ScrollBar_Margin.Size = new System.Drawing.Size(844, 27);
            this.ScrollBar_Margin.TabIndex = 4;
            this.ScrollBar_Margin.Value = 1;
            this.ScrollBar_Margin.Scroll += new System.Windows.Forms.ScrollEventHandler(this.ScrollBar_Margin_Scroll);
            this.ScrollBar_Margin.ValueChanged += new System.EventHandler(this.ScrollBar_Margin_ValueChanged);
            // 
            // comboBox_UpWaves
            // 
            this.comboBox_UpWaves.FormattingEnabled = true;
            this.comboBox_UpWaves.Location = new System.Drawing.Point(512, 482);
            this.comboBox_UpWaves.Name = "comboBox_UpWaves";
            this.comboBox_UpWaves.Size = new System.Drawing.Size(174, 21);
            this.comboBox_UpWaves.TabIndex = 5;
            this.comboBox_UpWaves.SelectedIndexChanged += new System.EventHandler(this.comboBox_UpWaves_SelectedIndexChanged);
            // 
            // comboBox_DownWaves
            // 
            this.comboBox_DownWaves.FormattingEnabled = true;
            this.comboBox_DownWaves.Location = new System.Drawing.Point(313, 482);
            this.comboBox_DownWaves.Name = "comboBox_DownWaves";
            this.comboBox_DownWaves.Size = new System.Drawing.Size(173, 21);
            this.comboBox_DownWaves.TabIndex = 6;
            this.comboBox_DownWaves.SelectedIndexChanged += new System.EventHandler(this.comboBox_DownWaves_SelectedIndexChanged);
            // 
            // label_DownWaves
            // 
            this.label_DownWaves.AutoSize = true;
            this.label_DownWaves.Location = new System.Drawing.Point(365, 517);
            this.label_DownWaves.Name = "label_DownWaves";
            this.label_DownWaves.Size = new System.Drawing.Size(72, 13);
            this.label_DownWaves.TabIndex = 7;
            this.label_DownWaves.Text = "Down Waves";
            // 
            // label_UpWaves
            // 
            this.label_UpWaves.AutoSize = true;
            this.label_UpWaves.Location = new System.Drawing.Point(562, 517);
            this.label_UpWaves.Name = "label_UpWaves";
            this.label_UpWaves.Size = new System.Drawing.Size(58, 13);
            this.label_UpWaves.TabIndex = 8;
            this.label_UpWaves.Text = "Up Waves";
            // 
            // label_Margin
            // 
            this.label_Margin.AutoSize = true;
            this.label_Margin.Location = new System.Drawing.Point(484, 319);
            this.label_Margin.Name = "label_Margin";
            this.label_Margin.Size = new System.Drawing.Size(39, 13);
            this.label_Margin.TabIndex = 9;
            this.label_Margin.Text = "Margin";
            // 
            // Form_ChartDisplay
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1124, 571);
            this.Controls.Add(this.label_Margin);
            this.Controls.Add(this.label_UpWaves);
            this.Controls.Add(this.label_DownWaves);
            this.Controls.Add(this.comboBox_DownWaves);
            this.Controls.Add(this.comboBox_UpWaves);
            this.Controls.Add(this.ScrollBar_Margin);
            this.Controls.Add(this.dateTimePicker_EndRefresh);
            this.Controls.Add(this.dateTimePicker_StartRefresh);
            this.Controls.Add(this.button_Refresh);
            this.Controls.Add(this.chart_Candlesticks);
            this.Name = "Form_ChartDisplay";
            this.Text = "Form2";
            ((System.ComponentModel.ISupportInitialize)(this.chart_Candlesticks)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataVisualization.Charting.Chart chart_Candlesticks;
        private System.Windows.Forms.Button button_Refresh;
        private System.Windows.Forms.DateTimePicker dateTimePicker_StartRefresh;
        private System.Windows.Forms.DateTimePicker dateTimePicker_EndRefresh;
        private System.Windows.Forms.HScrollBar ScrollBar_Margin;
        private System.Windows.Forms.ComboBox comboBox_UpWaves;
        private System.Windows.Forms.ComboBox comboBox_DownWaves;
        private System.Windows.Forms.Label label_DownWaves;
        private System.Windows.Forms.Label label_UpWaves;
        private System.Windows.Forms.Label label_Margin;
    }
}