﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project2_MJP
{
    public partial class Form_Start : Form
    {
        public Form_Start()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button_LoadTicker_Click(object sender, EventArgs e)
        {
            openFileDialog_LoadTicker.ShowDialog();
        }

        private void openFileDialog_LoadTicker_FileOk(object sender, CancelEventArgs e)
        {
            foreach (var filename in openFileDialog_LoadTicker.FileNames)
            {
                Form_ChartDisplay f = new Form_ChartDisplay(filename, dateTimePicker_StartDate.Value, dateTimePicker_EndDate.Value)
                {
                    Text = filename
                };
                f.Show();
            }

        }
    }
}
