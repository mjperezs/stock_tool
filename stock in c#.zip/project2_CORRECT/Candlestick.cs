﻿using System;
using System.Globalization;

namespace StockAnalysis
{
    public class Candlestick
    {
        // Properties for candlestick data 
        public DateTime Date { get; set; } // Date of the candlestick data
        public decimal Open { get; set; } // Opening price 
        public decimal High { get; set; } // Highest price  during the period
        public decimal Low { get; set; } // Lowest price during the period
        public decimal Close { get; set; } // Closing price
        public ulong Volume { get; set; } // Trading volume 

    
        /// Constructor that parses a CSV-formatted string into a Candlestick object.
        public Candlestick(string data)
        {
            // Define separators for splitting the CSV line (commas and double quotes)
            var separators = new char[] { ',', '"' };

            // Split the input string into individual values using the defined separators
            var values = data.Split(separators, StringSplitOptions.RemoveEmptyEntries);

            // Check if the CSV data has exactly 6 values (Date, Open, High, Low, Close, Volume)
            if (values.Length != 6)
            {
                // Throw an exception if the format is incorrect
                throw new ArgumentException("Invalid data format. Expected 5 values separated by commas and quotes.");
            }

            // Parse and assign values from the CSV line
            Date = DateTime.ParseExact(values[0].Trim(), "yyyy-MM-dd", CultureInfo.InvariantCulture); // Parse the date
            Open = Math.Round(decimal.Parse(values[1].Trim()), 2); // Parse and round the opening price to 2 decimal places
            High = Math.Round(decimal.Parse(values[2].Trim()), 2); // Parse and round the highest price
            Low = Math.Round(decimal.Parse(values[3].Trim()), 2); // Parse and round the lowest price
            Close = Math.Round(decimal.Parse(values[4].Trim()), 2); // Parse and round the closing price
            Volume = ulong.Parse(values[5].Trim()); // Parse the trading volume as an unsigned long
        }

     
        /// Constructor that directly accepts values for the candlestick.
        public Candlestick(DateTime date, double open, double high, double low, double close, ulong volume)
        {
            Date = date; // Set the date of the candlestick
            Open = (decimal)open; // Convert and assign the opening price
            High = (decimal)high; // Convert and assign the highest price
            Low = (decimal)low; // Convert and assign the lowest price
            Close = (decimal)close; // Convert and assign the closing price
            Volume = volume; // Assign the trading volume
        }

        /// Provides a string representation of the candlestick object.
        public override string ToString()
        {
            // Returns the candlestick data formatted as a string
            return $"Date: {Date}, Open: {Open}, High: {High}, Low: {Low}, Close: {Close}, Volume: {Volume}";
        }
    }
}
