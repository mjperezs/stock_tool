﻿using StockAnalysis;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace project2_MJP
{
    public partial class Form_ChartDisplay : Form
    {
        /// <summary>
        /// Gets or sets the file path of the stock data file.
        /// </summary>
        public string filePath;

        /// <summary>
        /// Holds the complete list of unfiltered candlestick data.
        /// </summary>
        private List<Candlestick> candlesticks; //unifltered

        /// <summary>
        /// Holds the filtered list of candlestick data based on the selected date range.
        /// </summary>
        private List<Candlestick> filteredCandlesticks;  // filtered 

        /// <summary>
        /// Provides functionality to read stock data from files.
        /// </summary>
        StockReader stockReader;

        /// <summary>
        /// Gets or sets the currently selected wave.
        /// </summary>
        public Wave selectedWave { get; set; }


        public Form_ChartDisplay()
        {
            InitializeComponent();

           
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Form_ChartDisplay"/> class with the specified file path and date range.
        /// </summary>
        /// <param name="originalFilePath">The file path to the stock data CSV.</param>
        /// <param name="startDate">The start date for filtering candlestick data.</param>
        /// <param name="endDate">The end date for filtering candlestick data.</param>
        public Form_ChartDisplay(String originalFilePath, DateTime startDate, DateTime endDate)
        {
            InitializeComponent(); //initialize the form components

            stockReader = new StockReader(); //create a new instance of StockReader

            filePath = originalFilePath; // set the file path to the provided originalFilePath
            dateTimePicker_StartRefresh.Value = startDate; // set the start date of the dateTimePicker control 
            dateTimePicker_EndRefresh.Value = endDate; // set the end date of the dateTimePicker control

            // Load the full candlesticks just once
            candlesticks = loadTicker(originalFilePath);

            //Load the data into the chart and display it
            loadAndDisplay();

            //show the form
            Show();


        }


        /// <summary>
        /// Loads candlestick data from a CSV file and ensures it is in chronological order.
        /// </summary>
        /// <param name="filename">The path to the CSV file containing candlestick data.</param>
        /// <returns>A chronologically ordered list of candlesticks.</returns>
        private List<Candlestick> loadTicker(string filename)
        {
            List<Candlestick> listOfCandlesticks = StockReader.ReadCandlesticksFromCsv(filename); //read candlestick data from a CSV file using StockReader
            Candlestick firstCandlestick = listOfCandlesticks[0]; //get the first candlestick from the list
            Candlestick secondCandlestick = listOfCandlesticks[1]; //get the second candlestick from the list
            if (firstCandlestick.Date > secondCandlestick.Date) //check if the first candlestick's date is later than the second's date
            {
                listOfCandlesticks.Reverse(); //if so, reverse the list to have the earliest data first
            }

            return listOfCandlesticks; // Return the properly ordered list of candlesticks
        }

        /// <summary>
        /// Loads data and updates the chart display.
        /// </summary>
        public void loadAndDisplay()
        {
            Text = filePath; //Set the form's title text to the file path

            displayStock(); //Display the stock data on the chart
        }

        /// <summary>
        /// Filters a list of candlesticks based on a specified start and end date.
        /// </summary>
        /// <param name="listOfCandlesticks">The list of candlesticks to filter.</param>
        /// <param name="startDate">The start date of the filter range.</param>
        /// <param name="endDate">The end date of the filter range.</param>
        /// <returns>A list of candlesticks within the specified date range.</returns>
        public List<Candlestick> FilterCandlesticksByDate(List<Candlestick> listOfCandlesticks, DateTime startDate, DateTime endDate)
        {
            //return only those candlesticks whose dates are between startDate and endDate
            return listOfCandlesticks.Where(c => c.Date >= startDate && c.Date <= endDate).ToList(); 



        }


        /// <summary>
        /// Finds peaks and valleys in the provided candlestick data based on a specified margin.
        /// </summary>
        /// <param name="candlesticks">The list of candlesticks to analyze.</param>
        /// <param name="margin">The number of candlesticks to consider on either side for comparison.</param>
        /// <param name="peakIndices">Output list of indices where peaks occur.</param>
        /// <param name="valleyIndices">Output list of indices where valleys occur.</param>
        private void FindPeaksAndValleys( List<Candlestick> candlesticks, int margin, out List<int> peakIndices, out List<int> valleyIndices)
        {
            //initialize the lists that will hold indices of peaks and valleys
            peakIndices = new List<int>(); 
            valleyIndices = new List<int>();

            //if the candlestick list is null or empty, exit the method
            if (candlesticks == null || candlesticks.Count == 0) return;

            //ensure that the margin is at least 1
            if (margin < 1) margin = 1;

            //loop through each candlestick in the list
            for (int i = 0; i < candlesticks.Count; i++)
            {
                //determine the start and end indices of the window based on the margin
                int start = Math.Max(i - margin, 0);
                int end = Math.Min(i + margin, candlesticks.Count - 1);

                //get the current candlestick's high and low values
                decimal currentHigh = candlesticks[i].High;
                decimal currentLow = candlesticks[i].Low;

                //assume the current candlestick is both a peak and a valley until proven otherwise
                bool isPeak = true;
                bool isValley = true;

                //loop over the margin window to compare the current candlestick with its neighbors
                for (int j = start; j <= end; j++)
                {
                    if (candlesticks[j].High > currentHigh) isPeak = false;
                    if (candlesticks[j].Low < currentLow) isValley = false;
                }

                if (isPeak) peakIndices.Add(i); //if the current candlestick is a peak, add its index to peakIndices
                if (isValley) valleyIndices.Add(i); //if the current candlestick is a valley, add its index to valleyIndices
            }

        }

        /// <summary>
        /// Annotates the chart with markers for peaks (P) and valleys (V) based on the filtered candlestick data.
        /// </summary>
        private void AnnotatePeaksAndValleys()
        {
            
            chart_Candlesticks.Annotations.Clear(); /// Clear any existing annotations on the chart

            int margin = ScrollBar_Margin.Value; //Get the current margin value from the scroll bar control


            List<Candlestick> data = filteredCandlesticks; // Use the filtered candlestick data for annotation
            if (data == null || data.Count == 0) return; //If there is no data, exit the method

            FindPeaksAndValleys(data, margin, out var peakIndices, out var valleyIndices); //Find the indices of peaks and valleys within the filtered data

            Series seriesOHLC = chart_Candlesticks.Series["Series_OHLC"]; //Get the OHLC series from the chart to determine where to place annotations
            if (seriesOHLC.Points.Count == 0) return; // If the series does not contain any points, exit the method

            //Loop through each detected peak index to create a peak annotation
            foreach (int idx in peakIndices)
            {
                // Check that the index is valid within the series points count
                if (idx < seriesOHLC.Points.Count)
                {
                    // Create a new text annotation for the peak
                    TextAnnotation peakAnno = new TextAnnotation
                    {
                        Text = "P",
                        ForeColor = Color.Green,
                        Font = new Font("Arial", 8, FontStyle.Bold),
                        AnchorDataPoint = seriesOHLC.Points[idx],
                        AnchorAlignment = ContentAlignment.BottomCenter
                    };
                    // Add the peak annotation to the chart
                    chart_Candlesticks.Annotations.Add(peakAnno);
                }
            }

            // Loop through each detected valley index to create a valley annotation
            foreach (int idx in valleyIndices)
            {
                // Check that the index is valid within the series points count
                if (idx < seriesOHLC.Points.Count)
                {
                    // Create a new text annotation for the valley
                    TextAnnotation valleyAnno = new TextAnnotation
                    {
                        Text = "V",
                        ForeColor = Color.Red,
                        Font = new Font("Arial", 8, FontStyle.Bold),
                        AnchorDataPoint = seriesOHLC.Points[idx],
                        AnchorAlignment = ContentAlignment.TopCenter
                    };
                    // Add the valley annotation to the chart
                    chart_Candlesticks.Annotations.Add(valleyAnno);
                }
            }
        }


        /// <summary>
        /// Builds wave objects (up waves and down waves) from the given peak and valley indices.
        /// </summary>
        /// <param name="peakIndices">A list of indices representing peaks.</param>
        /// <param name="valleyIndices">A list of indices representing valleys.</param>
        /// <param name="data">The candlestick data used to determine wave dates.</param>
        /// <param name="upWaves">Output list of detected up waves.</param>
        /// <param name="downWaves">Output list of detected down waves.</param>
        private void BuildWaves(
            List<int> peakIndices,
            List<int> valleyIndices,
            List<Candlestick> data,
            out List<Wave> upWaves,
            out List<Wave> downWaves)
        {
            // Initialize lists to hold up and down waves
            upWaves = new List<Wave>();
            downWaves = new List<Wave>();

            // Merge the peak and valley indices and sort them in ascending order
            List<int> combined = peakIndices.Concat(valleyIndices).OrderBy(x => x).ToList();

            // Iterate over the combined list to detect waves between consecutive points
            for (int i = 0; i < combined.Count - 1; i++)
            {
                // Get the current and next index from the combined list
                int curr = combined[i];
                int next = combined[i + 1];

                // Check for an up wave pattern 
                bool currIsValley = valleyIndices.Contains(curr);
                bool nextIsPeak = peakIndices.Contains(next);
                if (currIsValley && nextIsPeak)
                {
                    // Create and add a new up wave with the appropriate indices and dates
                    upWaves.Add(new Wave
                    {
                        StartIndex = curr,
                        EndIndex = next,
                        StartDate = data[curr].Date,
                        EndDate = data[next].Date,
                        IsUpWave = true
                    });
                }

                // Check for a down wave pattern
                bool currIsPeak = peakIndices.Contains(curr);
                bool nextIsValley = valleyIndices.Contains(next);
                if (currIsPeak && nextIsValley)
                {
                    // Create and add a new down wave with the appropriate indices and dates
                    downWaves.Add(new Wave
                    {
                        StartIndex = curr,
                        EndIndex = next,
                        StartDate = data[curr].Date,
                        EndDate = data[next].Date,
                        IsUpWave = false
                    });
                }
            }
        }



        /// <summary>
        /// Displays the stock data on the chart by filtering, normalizing, binding, and annotating the data.
        /// </summary>
        public void displayStock()
        {
            // Filter the complete candlestick data based on the selected date range
            filteredCandlesticks = FilterCandlesticksByDate(
                candlesticks,
                dateTimePicker_StartRefresh.Value,
                dateTimePicker_EndRefresh.Value);

            // If there is no filtered data, clear the chart and exit
            if (filteredCandlesticks == null || filteredCandlesticks.Count == 0)
            {
                chart_Candlesticks.DataSource = null;
                chart_Candlesticks.DataBind();
                return;
            }

            // Normalize
            normalizeChart(filteredCandlesticks);

            // Bind chart to the *filtered* list
            chart_Candlesticks.DataSource = filteredCandlesticks;
            chart_Candlesticks.DataBind();

            // Annotate peaks/valleys
            AnnotatePeaksAndValleys();

            //  Build waves -> populate combos
            PopulateWaveComboBoxes();

            //Make sure the chart is visible
            chart_Candlesticks.Show();
        }

        /// <summary>
        /// Normalizes the chart's Y-axis based on the minimum and maximum values of the provided candlestick data.
        /// </summary>
        /// <param name="listOfCandlesticks">The candlestick data used to determine the Y-axis scale.</param>
        public void normalizeChart(List<Candlestick> listOfCandlesticks)
        {
            // If the provided list is null or empty, exit the method
            if (listOfCandlesticks == null || listOfCandlesticks.Count == 0)
            {
               
                return;
            }

            // Determine the minimum low value from the candlesticks
            decimal minValue = listOfCandlesticks.Min(c => c.Low);
            //Determine the maximum high value from the candlesticks
            decimal maxValue = listOfCandlesticks.Max(c => c.High);

            // Calculate padding as 5% of the difference between max and min values
            decimal padding = (maxValue - minValue) * 0.05m;
            decimal minY = minValue - padding;
            decimal maxY = maxValue + padding;

            //set the y axis min and max values
            chart_Candlesticks.ChartAreas["ChartArea_OHLC"].AxisY.Minimum = Math.Round((double)minValue, 2);
            chart_Candlesticks.ChartAreas["ChartArea_OHLC"].AxisY.Maximum = Math.Round((double)maxValue, 2);

        }

        /// <summary>
        /// Handles the click event for the Refresh button and updates the stock display.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The event data.</param>
        private void button_Refresh_Click(object sender, EventArgs e)
        {
            // Update the stock display on the chart
            displayStock();

        }


        private void chart_Candlesticks_Click(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// Handles the event when the margin scroll bar's value changes, updating the display.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The event data.</param>
        private void ScrollBar_Margin_ValueChanged(object sender, EventArgs e)
        {
            // Refresh the chart display when the margin value changes
            displayStock();
        }

        /// <summary>
        /// Represents an up wave or down wave identified in the candlestick data.
        /// </summary>
        public class Wave
        {
            /// <summary>
            /// Gets or sets the starting index of the wave in the candlestick list.
            /// </summary>
            public int StartIndex { get; set; }

            /// <summary>
            /// Gets or sets the ending index of the wave in the candlestick list.
            /// </summary>
            public int EndIndex { get; set; }

            /// <summary>
            /// Gets or sets the start date of the wave.
            /// </summary>
            public DateTime StartDate { get; set; }

            /// <summary>
            /// Gets or sets the end date of the wave.
            /// </summary>
            public DateTime EndDate { get; set; }

            /// <summary>
            /// Gets or sets a value indicating whether the wave is upward.
            /// </summary>
            public bool IsUpWave { get; set; }

            /// <summary>
            /// Returns a string representation of the wave's date range.
            /// </summary>
            /// <returns>A string in the format "StartDate - EndDate".</returns>
            public override string ToString()
            {
                return $"{StartDate.ToShortDateString()} - {EndDate.ToShortDateString()}";
            }
        }

        /// <summary>
        /// Populates the combo boxes with the detected up waves and down waves based on the filtered candlestick data.
        /// </summary>
        private void PopulateWaveComboBoxes()
        {
            // Get the current margin value from the scroll bar
            int margin = ScrollBar_Margin.Value;
            // If there is no filtered candlestick data, clear the combo box data sources and exit
            if (filteredCandlesticks == null || filteredCandlesticks.Count == 0)
            {
                comboBox_UpWaves.DataSource = null;
                comboBox_DownWaves.DataSource = null;
                return;
            }

            //Find peak/valleys
            FindPeaksAndValleys(filteredCandlesticks, margin, out var peakIdx, out var valleyIdx);

            // Build waves
            BuildWaves(peakIdx, valleyIdx, filteredCandlesticks, out var upWaves, out var downWaves);

            // Bind combos
            comboBox_UpWaves.DataSource = upWaves;
            comboBox_DownWaves.DataSource = downWaves;
        }

        /// <summary>
        /// Draws a wave on the chart based on the specified wave and candlestick data.
        /// </summary>
        /// <param name="wave">The wave to draw.</param>
        /// <param name="data">The candlestick data used for drawing the wave.</param>
        /// <param name="isUpWave">A boolean indicating whether the wave is upward.</param>
        private void DrawWave(Wave wave, List<Candlestick> data, bool isUpWave)
        {
            // Remove any previous wave-related annotations from the chart
            ClearWaveAnnotations();

            // If the wave or data is null or empty, exit the method
            if (wave == null || data == null || data.Count == 0) return;

            // Compute min & max
            decimal minPrice = data.Skip(wave.StartIndex)
                                   .Take(wave.EndIndex - wave.StartIndex + 1)
                                   .Min(c => c.Low);
            decimal maxPrice = data.Skip(wave.StartIndex)
                                   .Take(wave.EndIndex - wave.StartIndex + 1)
                                   .Max(c => c.High);

            //Convert the start and end dates to OLE Automation dates for charting
            double xStart = data[wave.StartIndex].Date.ToOADate();
            double xEnd = data[wave.EndIndex].Date.ToOADate();

            //Create a rectangle annotation to visually represent the wave's area
            var rect = new RectangleAnnotation
            {
                Name = "waveRectangle", // <-- CHANGED
                AxisX = chart_Candlesticks.ChartAreas["ChartArea_OHLC"].AxisX,
                AxisY = chart_Candlesticks.ChartAreas["ChartArea_OHLC"].AxisY,
                LineColor = isUpWave ? Color.Green : Color.Red,
                BackColor = Color.Transparent,
               
                ClipToChartArea = "ChartArea_OHLC",// <-- CHANGED
                X = xStart,
                Y = (double)maxPrice,
                Width = xEnd - xStart,
                Height = (double)(maxPrice - minPrice)
            };
            // Add the rectangle annotation to the chart
            chart_Candlesticks.Annotations.Add(rect);

            //Create a line annotation to represent the wave trend
            var diag = new LineAnnotation
            {
                Name = "waveLine",     // <-- CHANGED
                AxisX = chart_Candlesticks.ChartAreas["ChartArea_OHLC"].AxisX,
                AxisY = chart_Candlesticks.ChartAreas["ChartArea_OHLC"].AxisY,
                LineColor = isUpWave ? Color.Green : Color.Red,
                LineWidth = 2,
                
                ClipToChartArea = "ChartArea_OHLC" // <-- CHANGED
            };

            //Set the coordinates for the line annotation based on whether the wave is up or down
            if (isUpWave)
            {
                // For an up wave, start at the low of the starting candlestick and end at the high of the ending candlestick
                diag.X = xStart;
                diag.Y = (double)data[wave.StartIndex].Low;
                diag.AnchorX = xEnd;
                diag.AnchorY = (double)data[wave.EndIndex].High;
            }
            else
            {
                // For a down wave, start at the high of the starting candlestick and end at the low of the ending candlestick
                diag.X = xStart;
                diag.Y = (double)data[wave.StartIndex].High;
                diag.AnchorX = xEnd;
                diag.AnchorY = (double)data[wave.EndIndex].Low;
            }

            //Add the line annotation to the chart
            chart_Candlesticks.Annotations.Add(diag);

        }

        /// <summary>
        /// Removes any annotations related to wave drawings from the chart.
        /// </summary>
        private void ClearWaveAnnotations()
        {
            //// Loop backwards through the annotations collection 
            for (int i = chart_Candlesticks.Annotations.Count - 1; i >= 0; i--)
            {
                // Get the current annotation
                var anno = chart_Candlesticks.Annotations[i];
                // If the annotation is either a wave rectangle or wave line, remove it
                if (anno.Name == "waveRectangle" || anno.Name == "waveLine")
                {
                    chart_Candlesticks.Annotations.RemoveAt(i);
                }
            }
        }

        /// <summary>
        /// Draws the currently selected wave on the chart using the filtered candlestick data.
        /// </summary>
        private void DrawSelectedWave()
        {
            // Check if a wave is selected and if filtered candlestick data is available
            if (selectedWave == null ||
                filteredCandlesticks == null ||
                filteredCandlesticks.Count == 0)
                return;

            // Clear only wave annotations
            ClearWaveAnnotations();

            // fetch start/end from the same filteredCandlesticks
            var startCandle = filteredCandlesticks[selectedWave.StartIndex];
            var endCandle = filteredCandlesticks[selectedWave.EndIndex];

            // Calculate the X-axis positions
            double startX = selectedWave.StartIndex + 1;
            double endX = selectedWave.EndIndex + 1;

            double startY, endY;

            // Determine the Y-axis positions based on whether the wave is up or down
            if (!selectedWave.IsUpWave) // down wave
            {
                startY = (double)startCandle.High;
                endY = (double)endCandle.Low;
            }
            else // up wave
            {
                startY = (double)startCandle.Low;
                endY = (double)endCandle.High;
            }

            Color waveColor = selectedWave.IsUpWave ? Color.Green : Color.Red;

            // Get a reference to the chart area for annotations
            var chartArea = chart_Candlesticks.ChartAreas["ChartArea_OHLC"];
            var rect = new RectangleAnnotation
            {
                Name = "waveRectangle", // so ClearWaveAnnotations can remove it
                AxisX = chartArea.AxisX,
                AxisY = chartArea.AxisY,
                X = startX,
                Y = Math.Max(startY, endY),
                Width = endX - startX,
                Height = Math.Abs(endY - startY) * -1,
                BackColor = Color.FromArgb(30, waveColor),
                LineColor = waveColor,
                LineWidth = 3,
                IsSizeAlwaysRelative = false,
                ClipToChartArea = chartArea.Name,
               
            };
            // Add the rectangle annotation to the chart
            chart_Candlesticks.Annotations.Add(rect);

            // Create a line annotation to represent the wave's trend
            var line = new LineAnnotation
            {
                Name = "waveLine",
                AxisX = chartArea.AxisX,
                AxisY = chartArea.AxisY,
                X = startX,
                Y = startY,
                Width = endX - startX,
                Height = endY - startY,
                LineColor = waveColor,
                LineWidth = 2,
                IsSizeAlwaysRelative = false,
                ClipToChartArea = chartArea.Name,
                
            };
            // Add the line annotation to the chart
            chart_Candlesticks.Annotations.Add(line);

            // Force the chart to redraw and show the new annotations
            chart_Candlesticks.Invalidate();

        }

        /// <summary>
        /// Handles the event when the up waves combo box selection changes.
        /// Updates the selected wave and draws it on the chart.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The event data.</param>
        private void comboBox_UpWaves_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Get the selected wave from the combo box
            var wave = comboBox_UpWaves.SelectedItem as Wave;

            // If no wave is selected, exit the method
            if (wave == null) return;

            // Set the selectedWave property to the chosen wave
            selectedWave = wave;

            // Draw using the filtered data, ensuring indices match
            DrawSelectedWave();

        }

        /// <summary>
        /// Handles the event when the down waves combo box selection changes.
        /// Updates the selected wave and draws it on the chart.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The event data.</param>
        private void comboBox_DownWaves_SelectedIndexChanged(object sender, EventArgs e)
        {
            var wave = comboBox_DownWaves.SelectedItem as Wave;
            if (wave == null) return;

            selectedWave = wave;
            // Draw the selected wave on the chart using the filtered data
            DrawSelectedWave();
        }


        /// <summary>
        /// Handles the scroll event of the margin scroll bar, refreshing the stock display.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The scroll event data.</param>
        private void ScrollBar_Margin_Scroll(object sender, ScrollEventArgs e)
        {
            // Refresh the stock display when the margin scroll value changes
            displayStock();

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void chart_Candlesticks_Click_1(object sender, EventArgs e)
        {

        }
    }
}
